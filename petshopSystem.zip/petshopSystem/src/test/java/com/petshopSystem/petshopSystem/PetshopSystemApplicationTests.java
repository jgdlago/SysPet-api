package com.petshopSystem.petshopSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
