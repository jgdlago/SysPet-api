package com.petshopSystem.petshopSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetshopSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetshopSystemApplication.class, args);
	}

}
